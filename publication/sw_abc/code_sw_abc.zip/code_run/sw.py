import numpy as np


def expected_swdistance(X, Y, n_montecarlo=1, L=100, p=2, T=100):
    X = np.stack([X] * n_montecarlo)
    M, N, d = X.shape
    order = p
    # Project data
    theta = np.random.randn(M, L, d)
    theta = theta / (np.sqrt((theta ** 2).sum(axis=2))
                     )[:, :, None]  # Normalize
    theta = np.transpose(theta, (0, 2, 1))
    xproj = np.matmul(X, theta)
    yproj = np.matmul(Y, theta)
    # Compute percentiles
    # T = 10 ** 4
    # t = np.linspace(0, 100, T + 2)
    # t = t[1:-1]
    # xqf = (np.percentile(xproj, q=t, axis=1))
    # yqf = (np.percentile(yproj, q=t, axis=1))
    # Compute expected SW distance
    # diff = (xqf - yqf).transpose((1, 0, 2))
    # sw_dist = (np.abs(diff) ** order).mean()
    sw_dist = (np.abs(np.sort(xproj, 1) - np.sort(yproj, 1)) ** order).mean()
    # import pdb
    # pdb.set_trace()
    return sw_dist ** (1 / order)
