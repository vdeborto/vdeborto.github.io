import numpy as np
import pickle
from patch_fun import patch2im, im2patch, extract_patch


def noisy_image(im, params):
    noise_type = params['noise_type']
    if noise_type == 'gaussian':
        sigma = params['sigma']
        im_noise = im + sigma * np.random.randn(*im.shape)
    elif noise_type == 'salt':
        percent = params['percent']
        shape = im.shape
        size = im.size
        nb = int(percent * size)

        im_vec = im.reshape(size)
        pos = np.random.randint(0, size, nb)
        ber = np.random.binomial(1, 0.5, nb)
        im_vec[pos] = ber * 255
        im_noise = im_vec.reshape(shape)
    return im_noise


def dictionary_learning(im_noise, nclass, r, rA, save=False, stride=1):
    (Nx, Ny) = im_noise.shape
    patch_arr, patch_arr_rA = im2patch(im_noise, r, rA)
    D = np.zeros((nclass, (2 * r + 1) ** 2))
    list_int_patch = [[] for k in range(nclass)]
    list_int_posx = [[] for k in range(nclass)]
    list_int_posy = [[] for k in range(nclass)]

    val_patch = np.zeros((Nx, Ny, nclass))

    for k in range(nclass):
        x = np.random.randint(Nx)
        y = np.random.randint(Ny)
        patch = patch_arr[x, y, :]
        D[k, :] = patch - np.mean(patch)  # WE REMOVE THE MEAN OF THE PATCH

        list_int_patch[k].append(patch_arr_rA[x, y])
        list_int_posx[k].append(x)
        list_int_posy[k].append(y)

    print('projecting on dictionary...')

    for x in range(0, Nx, stride):
        for y in range(0, Ny, stride):
            patch = patch_arr[x, y]
            patch = patch - np.mean(patch)
            patch_big = patch_arr_rA[x, y]
            err = D - patch
            err_norm = np.linalg.norm(err, axis=-1)
            k = np.argmin(err_norm)
            list_int_patch[k].append(patch_big)
            list_int_posx[k].append(x)
            list_int_posy[k].append(y)

    # discard small classes
    NMIN = 20
    list_patch = []
    list_posx = []
    list_posy = []
    for k in range(len(list_int_patch)):
        if len(list_int_patch[k]) >= NMIN:
            list_patch.append(list_int_patch[k])
            list_posx.append(list_int_posx[k])
            list_posy.append(list_int_posy[k])

    if save:
        dic_dic = {'D': D,
                   'list_patch': list_patch,
                   'list_posx': list_posx,
                   'list_posy': list_posy}
        with open('dic.pickle', 'wb') as handle:
            pickle.dump(dic_dic, handle)

    return D, list_patch, list_posx, list_posy


def load_model(params, im_noise, nclass, r, rA):
    if 'patch_dic' in params.keys():
        name = params['patch_dic'] + '.pickle'
        with open(name, 'rb') as handle:
            patch_dic = pickle.load(handle)
            patch_arr = patch_dic['patch_arr']
            patch_arr_rA = patch_dic['patch_arr_rA']
    else:
        patch_arr, patch_arr_rA = im2patch(im_noise, r, rA)

    if 'dic_dic' in params.keys():
        name = params['dic_dic'] + '.pickle'
        with open(name, 'rb') as handle:
            dic_dic = pickle.load(handle)
            D = dic_dic['D']
            list_patch = dic_dic['list_patch']
            list_posx = dic_dic['list_posx']
            list_posy = dic_dic['list_posy']
    else:
        D, list_patch, list_posx, list_posy = dictionary_learning(
            im_noise, nclass, r, rA)

    return patch_arr, list_patch, list_posx, list_posy


def imsave(name, u):
    from PIL import Image
    u = u.clip(0, 255)
    result = Image.fromarray(u.astype(np.uint8))
    result.save(name + '.jpg')
