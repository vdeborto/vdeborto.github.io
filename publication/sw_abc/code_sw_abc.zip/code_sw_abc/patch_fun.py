import numpy as np
import pickle


def im2patch(im, r, rA, save=False):
    (Nx, Ny) = im.shape
    im_big = np.tile(im, (3, 3))  # handle boundary conditions

    from sklearn.feature_extraction.image import extract_patches
    R = r + rA
    all_patches = extract_patches(im_big, 2 * r + 1)
    all_patches_rA = extract_patches(im_big, 2 * R + 1)

    patch_arr = all_patches[(Nx - r):(2 * Nx - r), (Ny - r):(2 * Ny - r)]
    patch_arr_rA = all_patches_rA[(Nx - R):(2 * Nx - R), (Ny - R):(2 * Ny - R)]

    patch_arr = patch_arr.reshape(Nx, Ny, (2 * r + 1) ** 2)
    patch_arr_rA = patch_arr_rA.reshape(Nx, Ny, (2 * R + 1) ** 2)

    if save:
        patch_dic = {'patch_arr': patch_arr,
                     'patch_arr_rA': patch_arr_rA}
        with open('patch.pickle', 'wb') as handle:
            pickle.dump(patch_dic, handle)

    return patch_arr, patch_arr_rA


def patch2im(patch_arr, r):
    (Nx, Ny, _) = patch_arr.shape
    l = 2 * r + 1

    patch_arr = np.reshape(patch_arr, (Nx, Ny, l, l))
    for xr in range(l):
        for yr in range(l):
            xr_shift = xr - r
            yr_shift = yr - r
            channel = patch_arr[:, :, xr, yr]
            channel = np.roll(channel, xr_shift, 0)
            channel = np.roll(channel, yr_shift, 1)
            patch_arr[:, :, xr, yr] = channel
    im = np.mean(patch_arr, (-2, -1))
    return im


def extract_patch(z, pos, r):
    (N, s) = z.shape
    r1 = int(np.sqrt(s))
    middle = int(r1 / 2)
    z_mat = np.reshape(z, (N, r1, r1))
    pos_abs_x = middle + pos[0]
    pos_abs_y = middle + pos[1]
    z_out_mat = z_mat[:, pos_abs_x - r: pos_abs_x +
                      r + 1, pos_abs_y - r: pos_abs_y + r + 1]
    z_out = np.reshape(z_out_mat, (N, (2 * r + 1) ** 2))
    return z_out
