from tqdm import tqdm
import numpy as np
from patch_fun import patch2im, im2patch, extract_patch
from preprocess import dictionary_learning, load_model
from sw import expected_swdistance


def denoising(im_noise, params):
    # LOAD PARAMETERS AND MODEL
    r = params['r']
    rA = params['rA']
    epsilon = params['epsilon']
    K = params['K']
    T = params['T']
    nclass = params['nclass']
    weight = params['weight']
    p = params['p']
    patch_arr, list_patch, list_posx, list_posy = load_model(
        params, im_noise, nclass, r, rA)

    # CLUSTER LOOP
    denoise = []
    denoise_L2 = []
    print('looping on dictionary...')
    for k in tqdm(range(len(list_patch))):
        z_all = np.array(list_patch[k])
        y = extract_patch(z_all, [0, 0], r)
        length = y.shape[0]

        ind = np.random.randint(0, length, K)
        y_out = y[ind, :]
        y_out = y_out - np.mean(y_out, 1, keepdims=True)  # WE REMOVE THE MEAN

        if weight == 'boolean':
            sum_scalar = 1
            sum_patch = np.mean(y_out, 0)

            sum_scalar_L2 = 1
            sum_patch_L2 = y_out[0]
        else:
            sum_scalar, sum_scalar_L2 = (0, 0)
            sum_patch, sum_patch_L2 = (0, 0)

        poswT = np.random.randint(-rA, rA + 1, (T, 2))
        indT = np.random.randint(0, length, (T, K))
        for t in range(T):
            ind = indT[t]
            posw = poswT[t, :]
            z_all_out = z_all[ind, :]

            z_out = extract_patch(z_all_out, posw, r)
            # WE REMOVE THE MEAN
            z_out = z_out - np.mean(z_out, 1, keepdims=True)
            sw = expected_swdistance(z_out, y_out, p=p)
            sw = sw / (2 * r + 1) ** 2

            L2 = np.linalg.norm(z_out[0] - y_out[0])
            L2 = L2 / (2 * r + 1) ** 2

            patch = np.mean(z_out, 0)
            patch_L2 = z_out[0]
            if weight == 'boolean':
                bt = (sw < epsilon) * 1
                bt_L2 = (L2 < epsilon) * 1
            elif weight == 'gaussian':
                bt = np.exp(-sw ** 2 / (2 * epsilon))
                bt_L2 = np.exp(-L2 ** 2 / (2 * epsilon))
            sum_scalar += bt
            sum_patch += patch * bt
            sum_scalar_L2 += bt_L2
            sum_patch_L2 += patch_L2 * bt_L2

        denoise.append(sum_patch / sum_scalar)
        denoise_L2.append(sum_patch_L2 / sum_scalar_L2)

    # IMAGE ESTIMATOR
    patch_denoise = patch_arr - np.mean(patch_arr, -1, keepdims=True)
    patch_denoise_L2 = np.copy(patch_denoise)
    for k in range(len(list_patch)):
        for i in range(len(list_patch[k])):
            posx = list_posx[k][i]
            posy = list_posy[k][i]
            patch_denoise[posx, posy] = denoise[k]
            patch_denoise_L2[posx, posy] = denoise_L2[k]
    patch_denoise = patch_denoise + np.mean(patch_arr, -1, keepdims=True)
    patch_denoise_L2 = patch_denoise_L2 + np.mean(patch_arr, -1, keepdims=True)
    im_denoise = patch2im(patch_denoise, r)
    im_denoise_L2 = patch2im(patch_denoise_L2, r)

    return im_denoise, im_denoise_L2


def PSNR(u_true, u_estimated):
    error_sq = np.linalg.norm(u_true - u_estimated) ** 2 / u_true.size
    return -10 * np.log10(error_sq / u_true.ptp() ** 2)
