import numpy as np
from patch_fun import patch2im, im2patch, extract_patch
from preprocess import dictionary_learning, load_model


def nl_means_denoising(im_noise, params):
    # LOAD PARAMETERS AND MODEL
    r = params['r']
    rA = params['rA']
    h = params['h']
    stride = params['stride']
    nclass = params['nclass']
    patch_arr, list_patch, list_posx, list_posy = load_model(
        params, im_noise, nclass, r, rA)
    (Nx, Ny) = im_noise.shape

    # PIXEL LOOP
    patch_arr_denoise = patch_arr
    for x in range(0, Nx, stride):
        for y in range(0, Ny, stride):
            patch = patch_arr[x, y]
            xleft = np.max((0, x - rA))
            xright = np.min((x + rA, Nx - 1))
            yleft = np.max((0, y - rA))
            yright = np.min((y + rA, Ny - 1))

            patchw = patch_arr[xleft:xright + 1, yleft:yright + 1, :]
            S = np.linalg.norm(patchw - patch, axis=-1) ** 2
            S = S / (2 * r + 1) ** 2
            S = np.exp(- S / h ** 2)
            S = np.expand_dims(S, -1)
            P = patchw * S
            P = np.sum(P, axis=(0, 1)) / np.sum(S)

            stride2 = int(stride / 2)
            xleftp = np.max((0, x - stride2))
            xrightp = np.min((x + stride2, Nx - 1))
            yleftp = np.max((0, y - stride2))
            yrightp = np.min((y + stride2, Ny - 1))
            patch_arr_denoise[xleftp: xrightp + 1, yleftp: yrightp + 1, :] = P

    im_out = patch2im(patch_arr_denoise, r)

    return im_out
