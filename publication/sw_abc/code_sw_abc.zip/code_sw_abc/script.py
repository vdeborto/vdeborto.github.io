import vpv
import numpy as np
from slice_denoising import *
from patch_fun import *
from slice_denoising import *
import time
from PIL import Image
from preprocess import imsave, noisy_image
from classical_denoising import nl_means_denoising

# FILENAME
name = 'barbara'

sigma = 20
r = 3
rA = 10
epsilon = 0.3
K = 10
p = 2
T = 10
nclass = 10 ** 3
params = {'noise_type': 'gaussian',
          'sigma': sigma,
          'r': r,
          'epsilon': epsilon,
          'rA': rA,
          'K': K,
          'T': T,
          'p': p,
          'nclass': nclass,
          'weight': 'boolean',
          'patch_dic': 'patch',
          'dic_dic': 'dic'}

h = 0.8 * sigma
stride = 1
params_naive = {'r': r,
                'rA': rA,
                'h': h,
                'stride': stride,
                'nclass': nclass,
                'patch_dic': 'patch',
                'dic_dic': 'dic'}

# RANDOM SEED + LOAD IMAGE
np.random.seed(1)
im = np.array(Image.open(name + '.jpg'))
name = './res/' + name
N = im.shape[0]
im_noise = noisy_image(im, params)
imsave(name + '_noisy', im_noise)
imsave(name + '_original', im)

# COMPUTE AND SAVE PATCH + DICTIONARY(COMMENT IF ALREADY SAVED)
_ = im2patch(im_noise, r, rA, save=True)
t0 = time.time()
_ = dictionary_learning(im_noise, nclass, r, rA, save=True, stride=1)
tf = time.time()
dt = tf - t0
print('time elapsed projecting on dictionary: ' + str(dt))

# DENOISING
t0 = time.time()
denoise, denoise_L2 = denoising(im_noise, params)
tf = time.time()
dt = tf - t0
print('time elapsed SW-ABC NL-means: ' + str(dt))
t0 = time.time()
denoise_naive = nl_means_denoising(im_noise, params_naive)
tf = time.time()
dt = tf - t0
print('time elapsed naive NL-means: ' + str(dt))
imsave(name + '_denoise', denoise)
imsave(name + '_denoise_L2', denoise_L2)
imsave(name + '_denoise_naive', denoise_naive)
print('PSNR noisy: ' + str(PSNR(im, im_noise)))
print('PSNR restored: ' + str(PSNR(im, denoise)))
print('PSNR restored L2: ' + str(PSNR(im, denoise_L2)))
print('PSNR restored classical NL-means: ' + str(PSNR(im, denoise_naive)))
